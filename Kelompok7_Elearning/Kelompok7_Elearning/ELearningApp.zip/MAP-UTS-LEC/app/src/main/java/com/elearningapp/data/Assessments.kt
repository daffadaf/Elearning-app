package com.elearningapp.data

data class Assessments(
    val imageResourceId: Int,
    val name: String,
    val numberOfQuestions: Int,
    val duration: String
)