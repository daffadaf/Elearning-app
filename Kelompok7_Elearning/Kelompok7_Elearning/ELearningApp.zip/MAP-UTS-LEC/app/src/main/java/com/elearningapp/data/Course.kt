package com.elearningapp.data

data class Course(
    val imageResourceId: Int,
    val name: String,
    val numberOfLessons: Int,
    val duration: String
)