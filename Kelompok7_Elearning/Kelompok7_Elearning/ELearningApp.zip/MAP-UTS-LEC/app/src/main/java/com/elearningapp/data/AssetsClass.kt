package com.elearningapp.data

data class AssetsClass(
    val assetName: String,
    val actualAssetName: String,
    val chapterName: String,
    val subjectName: String,
    val chapterNumber: Int,

    )